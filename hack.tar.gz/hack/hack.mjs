import inspector from "inspector";
import { findAndSetBreakpoint } from "./util.mjs";

let shared = { scriptId: -1, breakpointId: -1, returnBreakpoint: -1 }
let lastScriptId = 0
const URLScriptId = new Map();
const NameExecutionDescription = new Map();

const session = new inspector.Session();
const secret = "1234"
session.connect();

setupDebugger();

function setupDebugger() {
  session.post("Debugger.enable", () => {
    subscribeToScriptId();
  });
  session.post('Runtime.enable')
}

function subscribeToScriptId() {
  session.on("Debugger.scriptParsed", message => {
    URLScriptId.set(message.params.url, message.params.scriptId);
    lastScriptId = message.params.scriptId
  });
  session.on("Runtime.executionContextCreated", message => {
    NameExecutionDescription.set(message.params.context.name, message)
  })
  session.on("Debugger.paused", message => {
    if (message.params.hitBreakpoints.includes(shared.returnBreakpoint)) session.post("Debugger.evaluateOnCallFrame", {
      callFrameId: message.params.callFrames[0].callFrameId, expression: 'typeof tmp === "undefined" ? false : tmp'
    }, (err, params) => {
      if (params.result.type === 'object') session.post("Debugger.setVariableValue", {
        scopeNumber: 0, callFrameId: message.params.callFrames[0].callFrameId, variableName: 'module', newValue: {
          objectId: params.result.objectId
        }
      })
    })

    if (!message.params.hitBreakpoints.includes(shared.breakpointId)) return
    session.post("Debugger.evaluateOnCallFrame", {
      callFrameId: message.params.callFrames[0].callFrameId, expression: "specifier"
    }, (err, params) => {
      if (!err && params.result.value.startsWith(`debug:${secret}:`)) {
        const specifier = params.result.value
        session.post("Debugger.evaluateOnCallFrame", {
          callFrameId: message.params.callFrames[0].callFrameId, expression: "specifier = 'util'"
        }, (err, params) => {
          session.post("Debugger.evaluateOnCallFrame", {
            callFrameId: message.params.callFrames[0].callFrameId,
            expression: `tmp = { getNamespace: ()=>this.${specifier.slice(`debug:${secret}:`.length)} }`
          }, (err, params) => {
            session.post('Debugger.resume')
          })
        })
      } else session.post("Debugger.resume")
    })
  })
}

export function install() {
  return new Promise(resolve => {
    for (let scriptId = Number(lastScriptId); scriptId >= 0; scriptId--) {
      session.post("Debugger.getScriptSource", {
        scriptId: scriptId.toString()
      }, async (err, params) => {
        if (params?.scriptSource.includes("async import(specifier, parentURL, importAttributes) {\n" + "    const moduleJob = await this.getModuleJob(specifier, parentURL, importAttributes);\n" + "    const { module } = await moduleJob.run();\n" + "    return module.getNamespace();\n" + "  }")) {
          shared.scriptId = scriptId.toString()
          shared.breakpointId = await findAndSetBreakpoint(session, scriptId.toString(), "const moduleJob = await this.getModuleJob(specifier, parentURL, importAttributes);")
          shared.returnBreakpoint = await findAndSetBreakpoint(session, scriptId.toString(), "    return module.getNamespace();")
          resolve()
        }
      })
    }
  })
}


"use strict";
export function getLineNoOf(session, scriptId, code) {
  return new Promise((resolve, reject) => session.post("Debugger.getScriptSource", {
    scriptId
  }, (err, params) => {
    if (err)
      reject(err);
    const source = params.scriptSource;
    if (!source)
      reject("scriptSource is empty");
    const pos = source.indexOf(code);
    if (pos === -1)
      reject("code not exist in script");
    const lines = source.substring(0, pos).split("\n");
    const lineNo = lines.length - 1;
    resolve({ lineNumber: lineNo, columnNumber: void 0 });
  }));
}
export function findAndSetBreakpoint(session, scriptId, code) {
  return new Promise((resolve) => {
    getLineNoOf(session, scriptId, code).then(({ lineNumber, columnNumber }) => {
      session.post("Debugger.setBreakpoint", {
        location: {
          scriptId,
          lineNumber,
          columnNumber
        }
      }, (err, params) => {
        if (!err)
          resolve(params.breakpointId);
      });
    });
  });
}
export {};

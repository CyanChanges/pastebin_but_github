import { install } from './hack.mjs'
import { pathToFileURL } from "url";

await import('./app.mjs')

// await reload()
await install()
await import('./app.mjs')
const cache = await import('debug:1234:loadCache')
cache.delete(pathToFileURL('/storage/emulated/0/Projects/WebstormProjects/koishi-bp/esmget/app.mjs').toString())
await import('./app.mjs')
cache.delete(pathToFileURL('/storage/emulated/0/Projects/WebstormProjects/koishi-bp/esmget/app.mjs').toString())
await import('./app.mjs')
cache.delete(pathToFileURL('/storage/emulated/0/Projects/WebstormProjects/koishi-bp/esmget/app.mjs').toString())
await import('./app.mjs')
cache.delete(pathToFileURL('/storage/emulated/0/Projects/WebstormProjects/koishi-bp/esmget/app.mjs').toString())
await import('./app.mjs')
cache.delete(pathToFileURL('/storage/emulated/0/Projects/WebstormProjects/koishi-bp/esmget/app.mjs').toString())
await import('./app.mjs')
debugger

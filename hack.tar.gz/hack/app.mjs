import { Context } from 'cordis'

export const app = new Context()
app.plugin(() => console.log('hello'))
await app.start()
